function iniciaSelfie() {
  let selfie = new window.BrScanSDKSelfie.Selfie(
    'sua-chave-aqui'
  )

  // Wizzard
  // selfie.wizzard = true;

  // Parametrização de URL de requisição ao serviço (para o uso de API PROXY)
  // selfie.servico.DOCUMENT_SERVER = "https://document.brscan.com.br"
  // selfie.servico.LIVENESS_SERVER = "https://liveness.brscan.com.br"
  // selfie.LIVENESS_TECH = "https://hml-livenesstech.brscan.com.br"

  // Tipo do processo de inicialização
  // selfie.processType = "liveness" -> 'enrollment' | 'liveness'
  // Mensagem que aparece no final do tipo processo
  // selfie.FacetecLivenessResultScreenSuccessMessage = "Sucesso!" -> 'liveness'
  // selfie.FacetecEnrollmentResultScreenSuccessMessage = "Sucesso!"; -> 'enrollment'
  // ID obrigatório em caso do processType = enrollment
  // selfie.externalDatabaseRefID = ""

  // Modifica elementos da experiência facetec

  // selfie.btnNormalColor = "#002DD1";
  // selfie.loadingTextColor = "#585858";
  // selfie.btnHighlightColor = "#1d4f91";
  // selfie.btnDisabledColor = "#cccccc";
  // selfie.btnBorderColor = "transparent";
  // selfie.btnBorderWidth = "0px";
  // selfie.btnBorderRadius = "20px";
  // selfie.ovalStrokeColor = "transparent";
  // selfie.ovalProgressColor1 = "#1d4f91";
  // selfie.ovalProgressColor2 = "#1d4f91";

  // selfie.resultAnimationSuccessBackgroundColor = "#008000";
  // selfie.resultAnimationSuccessForegroundColor = "#fff"

  // Cor do icone de sucesso
  // selfie.successBackgroundColor = "#09DEA1"

  // selfie.initialLoadingFont = "Roboto, sans-serif";
  // selfie.initialButtonFont = "Roboto, sans-serif";

  // Tela Inicial textos
  // selfie.readyScreenHeaderFont = "Roboto, sans-serif";
  // selfie.readyScreenHeaderTextColor = "#585858";
  // selfie.readyScreenSubtextFont = "Roboto, sans-serif";
  // selfie.readyScreenSubtextColor = "#585858";

  // Tela Tentar novamente textos
  // selfie.retryScreenHeaderFont = "Roboto, sans-serif"
  // selfie.retryScreenHeaderTextColor = "#585858"
  // selfie.retryScreenSubtextFont = "Roboto, sans-serif"
  // selfie.retryScreenSubtextTextColor = "#585858"
  // selfie.retryScreenImageBorderWidth = "2px"

  // Tela Capturar Selfie - textos de guia
  // selfie.feedbackCustomizationBackgroundColor = "rgba(45, 53, 73, 0.9)"
  // selfie.feedbackCustomizationTextColor = "#fff"
  // selfie.feedbackCustomizationTextFont = "Roboto, sans-serif"
  // selfie.feedbackCustomizationCornerRadius = "8px"
  // selfie.feedbackCustomizationShadow = "0px 6px 12px black";

  // selfie.resultAnimationSuccessBackgroundImage = ""
  // selfie.loadingBackgroundColor = "#1d4f91";
  // selfie.uploadProgressFillColor = "#375AD0";

  // Vocal Guidance
  // selfie.vocalGuidance = true;
  // selfie.vocalGuidanceLocation = '../vocalGuidance/'

  // Timeout de conexão lenta
  // selfie.conexaoTimeout = 0
  // Callback Opcional
  // selfie.iniciaSelfie(document.getElementById('selfie'), (callback) => {
  //   console.log('callback', callback)
  // })

  selfie.iniciaSelfie(document.getElementById('selfie'))
    .then(selfie => {
      console.log(selfie);
      alert('selfie recebida com sucesso');
    })
    .catch((err) => {
      console.log('err', err);
      // alert(err.desc);
    });
}

document.addEventListener("DOMContentLoaded", function (event) {
  iniciaSelfie();
});